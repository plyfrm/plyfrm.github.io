original song:
zts - far

arrange:
_

本体:
https://web.archive.org/web/20040606091451/http://danth.hp.infoseek.co.jp/file/musicbox7.rar



Please also Extract `__additional_charts_EXTRACT_ME.zip`

=================================

[ADDITIONAL]	☆1   5key_light
		☆4   5key_main

[ADDITIONAL]	☆5   7key_normal
		☆8   7key_hyper
		☆10  7key_another
[ADDITIONAL]	☆12  HHH
		★3   ROOT7
[ADDITIONAL]	★14  MANIAC7
[ADDITIONAL]	★17  地力7

[ADDITIONAL]	Lv28 9key_normal
		Lv36 9key_hyper

=================================